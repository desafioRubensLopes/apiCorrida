package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.AverageSpeed;
import io.swagger.model. Constructor;
import io.swagger.model.Driver;
import io.swagger.model.FastestLap;
import io.swagger.model.Time;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Result
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-09T19:08:55.979Z")

public class Result   {
  @JsonProperty("number")
  private Long number = null;

  @JsonProperty("position")
  private Integer position = null;

  @JsonProperty("positionText")
  private String positionText = null;

  @JsonProperty("points")
  private Integer points = null;

  @JsonProperty("Driver")
  private Driver Driver = null;

  @JsonProperty("Constructor")
  private  Constructor  Constructor = null;

  @JsonProperty("grid")
  private Integer grid = null;

  @JsonProperty("laps")
  private Integer laps = null;

  @JsonProperty("status")
  private String status = null;

  @JsonProperty("Time")
  private Time Time = null;

  @JsonProperty("FastestLap")
  private FastestLap FastestLap = null;



  public Result number(Long number) {
    this.number = number;
    return this;
  }

  /**
   * Get number
   * @return number
  **/
  @ApiModelProperty(example = "77", value = "")


  public Long getNumber() {
    return number;
  }

  public void setNumber(Long number) {
    this.number = number;
  }

  public Result position(Integer position) {
    this.position = position;
    return this;
  }

  /**
   * Get position
   * @return position
  **/
  @ApiModelProperty(example = "1", value = "")


  public Integer getPosition() {
    return position;
  }

  public void setPosition(Integer position) {
    this.position = position;
  }

  public Result positionText(String positionText) {
    this.positionText = positionText;
    return this;
  }

  /**
   * Get positionText
   * @return positionText
  **/
  @ApiModelProperty(example = "1", value = "")


  public String getPositionText() {
    return positionText;
  }

  public void setPositionText(String positionText) {
    this.positionText = positionText;
  }

  public Result points(Integer points) {
    this.points = points;
    return this;
  }

  /**
   * Get points
   * @return points
  **/
  @ApiModelProperty(example = "25", value = "")


  public Integer getPoints() {
    return points;
  }

  public void setPoints(Integer points) {
    this.points = points;
  }

  public Result Driver(Driver Driver) {
    this.Driver = Driver;
    return this;
  }

  /**
   * Get Driver
   * @return Driver
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Driver getDriver() {
    return Driver;
  }

  public void setDriver(Driver Driver) {
    this.Driver = Driver;
  }

  public Result  Constructor( Constructor  Constructor) {
    this. Constructor =  Constructor;
    return this;
  }

  /**
   * Get Constructor
   * @return Constructor
  **/
  @ApiModelProperty(value = "")

  @Valid

  public  Constructor getConstructor() {
    return  Constructor;
  }

  public void setConstructor( Constructor  Constructor) {
    this. Constructor =  Constructor;
  }

  public Result grid(Integer grid) {
    this.grid = grid;
    return this;
  }

  /**
   * Get grid
   * @return grid
  **/
  @ApiModelProperty(example = "1", value = "")


  public Integer getGrid() {
    return grid;
  }

  public void setGrid(Integer grid) {
    this.grid = grid;
  }

  public Result laps(Integer laps) {
    this.laps = laps;
    return this;
  }

  /**
   * Get laps
   * @return laps
  **/
  @ApiModelProperty(example = "55", value = "")


  public Integer getLaps() {
    return laps;
  }

  public void setLaps(Integer laps) {
    this.laps = laps;
  }

  public Result status(String status) {
    this.status = status;
    return this;
  }

  /**
   * Get status
   * @return status
  **/
  @ApiModelProperty(example = "Finished", value = "")


  public String getStatus() {
    return status;
  }

  public void setStatus(String status) {
    this.status = status;
  }

  public Result Time(Time Time) {
    this.Time = Time;
    return this;
  }

  /**
   * Get Time
   * @return Time
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Time getTime() {
    return Time;
  }

  public void setTime(Time Time) {
    this.Time = Time;
  }

  public Result FastestLap(FastestLap FastestLap) {
    this.FastestLap = FastestLap;
    return this;
  }

  /**
   * Get FastestLap
   * @return FastestLap
  **/
  @ApiModelProperty(value = "")

  @Valid

  public FastestLap getFastestLap() {
    return FastestLap;
  }

  public void setFastestLap(FastestLap FastestLap) {
    this.FastestLap = FastestLap;
  }

 

  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Result result = (Result) o;
    return Objects.equals(this.number, result.number) &&
        Objects.equals(this.position, result.position) &&
        Objects.equals(this.positionText, result.positionText) &&
        Objects.equals(this.points, result.points) &&
        Objects.equals(this.Driver, result.Driver) &&
        Objects.equals(this.Constructor, result.Constructor) &&
        Objects.equals(this.grid, result.grid) &&
        Objects.equals(this.laps, result.laps) &&
        Objects.equals(this.status, result.status) &&
        Objects.equals(this.Time, result.Time) &&
        Objects.equals(this.FastestLap, result.FastestLap);

  }

  @Override
  public int hashCode() {
    return Objects.hash(number, position, positionText, points, Driver,  Constructor, grid, laps, status, Time, FastestLap);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Result {\n");
    
    sb.append("    number: ").append(toIndentedString(number)).append("\n");
    sb.append("    position: ").append(toIndentedString(position)).append("\n");
    sb.append("    positionText: ").append(toIndentedString(positionText)).append("\n");
    sb.append("    points: ").append(toIndentedString(points)).append("\n");
    sb.append("    Driver: ").append(toIndentedString(Driver)).append("\n");
    sb.append("    Constructor: ").append(toIndentedString(Constructor)).append("\n");
    sb.append("    grid: ").append(toIndentedString(grid)).append("\n");
    sb.append("    laps: ").append(toIndentedString(laps)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    Time: ").append(toIndentedString(Time)).append("\n");
    sb.append("    FastestLap: ").append(toIndentedString(FastestLap)).append("\n");

    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

