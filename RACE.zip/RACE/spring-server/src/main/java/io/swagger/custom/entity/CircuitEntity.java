package io.swagger.custom.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.custom.repository.*;

@Entity
public class CircuitEntity implements Serializable {
	private static final long serialVersionUID = -5554866530519083481L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String circuitId;
	private String url;
	private String circuitName;
	private LocationEntity Location;
	public String getCircuitId() {
		return circuitId;
	}
	public void setCircuitId(String circuitId) {
		this.circuitId = circuitId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getCircuitName() {
		return circuitName;
	}
	public void setCircuitName(String circuitName) {
		this.circuitName = circuitName;
	}
	public LocationEntity getLocation() {
		return Location;
	}
	public void setLocation(LocationEntity location) {
		Location = location;
	}
	
	

}
