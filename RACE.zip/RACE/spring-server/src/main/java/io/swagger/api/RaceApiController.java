package io.swagger.api;

import io.swagger.model.Corrida;
import io.swagger.custom.service.CorridaService;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.annotations.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.*;
import javax.validation.Valid;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-09T19:08:55.979Z")

@Controller
public class RaceApiController implements RaceApi {

    private static final Logger log = LoggerFactory.getLogger(RaceApiController.class);

    private final ObjectMapper objectMapper;

    private final HttpServletRequest request;
    
    @Autowired
	private CorridaService corridaService;

    @org.springframework.beans.factory.annotation.Autowired
    public RaceApiController(ObjectMapper objectMapper, HttpServletRequest request) {
        this.objectMapper = objectMapper;
        this.request = request;
    }

    public ResponseEntity<Corrida> cadastraCorrida(@ApiParam(value = ""  )  @Valid @RequestBody Corrida corrida_) {
        String accept = request.getHeader("Accept");



        if (accept != null && accept.contains("application/json")) {
            try {
            	return corridaService.cadastraCorrida(corrida_);
            } catch (Exception e) {
                log.error("Couldn't serialize response for content type application/json", e);
                return new ResponseEntity<Corrida>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        return new ResponseEntity<Corrida>(HttpStatus.NOT_IMPLEMENTED);
    }

}
