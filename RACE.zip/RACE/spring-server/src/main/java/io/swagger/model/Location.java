package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Location
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-09T19:08:55.979Z")

public class Location   {
  @JsonProperty("lat")
  private Double lat = null;

  @JsonProperty("long")
  private Double longi = null;

  @JsonProperty("locality")
  private String locality = null;

  @JsonProperty("country")
  private String country = null;

  public Location lat(Double lat) {
    this.lat = lat;
    return this;
  }

  /**
   * Get lat
   * @return lat
  **/
  @ApiModelProperty(example = "24.4672", value = "")


  public Double getLat() {
    return lat;
  }

  public void setLat(Double lat) {
    this.lat = lat;
  }

  public Location longi(Double longi) {
    this.longi = longi;
    return this;
  }

  /**
   * Get longi
   * @return longi
  **/
  @ApiModelProperty(example = "54.6031", value = "")


  public Double getLong() {
    return longi;
  }

  public void setLong(Double longi) {
    this.longi = longi;
  }

  public Location locality(String locality) {
    this.locality = locality;
    return this;
  }

  /**
   * Get locality
   * @return locality
  **/
  @ApiModelProperty(example = "Abu Dhabi", value = "")


  public String getLocality() {
    return locality;
  }

  public void setLocality(String locality) {
    this.locality = locality;
  }

  public Location country(String country) {
    this.country = country;
    return this;
  }

  /**
   * Get country
   * @return country
  **/
  @ApiModelProperty(example = "UAE", value = "")


  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Location Location = (Location) o;
    return Objects.equals(this.lat, Location.lat) &&
        Objects.equals(this.longi, Location.longi) &&
        Objects.equals(this.locality, Location.locality) &&
        Objects.equals(this.country, Location.country);
  }

  @Override
  public int hashCode() {
    return Objects.hash(lat, longi, locality, country);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Location {\n");
    
    sb.append("    lat: ").append(toIndentedString(lat)).append("\n");
    sb.append("    longi: ").append(toIndentedString(longi)).append("\n");
    sb.append("    locality: ").append(toIndentedString(locality)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

