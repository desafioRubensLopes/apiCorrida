package io.swagger.custom.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import io.swagger.custom.repository.Corridas;
import io.swagger.custom.util.RespostasUtil;
import io.swagger.model.*;


@Service
public class CorridaService {
	
	public static final String MENSAGEM_NAO_AUTORIZADO = "cliente não autorizado";

	@Autowired
	private Corridas repository;
	
	@Autowired
    private RespostasUtil respostasUtil;
	

	public ResponseEntity<Corrida> cadastraCorrida(Corrida corrida_) {
		// TODO Auto-generated method stub
        try {
        	System.out.println("==> entrou no service");
        	return repository.incluirCorrida(corrida_);
        } catch (Exception e) {
            return new ResponseEntity<Corrida>(HttpStatus.INTERNAL_SERVER_ERROR);
        }   
	}
	


}
	

