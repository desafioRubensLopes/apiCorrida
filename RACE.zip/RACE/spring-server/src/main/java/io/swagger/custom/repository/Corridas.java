package io.swagger.custom.repository;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;

import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import io.swagger.model.*;
import io.swagger.custom.entity.*;
import io.swagger.custom.util.RespostasUtil;
import io.swagger.custom.util.UtilBanco;

@Repository
public class Corridas {

	public static final String MENSAGEM_NAO_ENCONTRADO = "registro não encontrado";
	public static final String MENSAGEM_INCLUSAO_NAO_REALIZADA = "registro não incluido";

	@Autowired
	private static RespostasUtil respostasUtil;

	@Autowired
	private UtilBanco utilBanco;
	private Corrida repository;

	String tabelaCorrida = "tcorrida";
	String tabelaResultado = "tresultado";
	String idCorrida;

	public ResponseEntity<Corrida> incluirCorrida(Corrida corrida_) {

		System.out.println("==> entrou no repository");


		List<Race> race = new ArrayList<Race>();
		race = corrida_.getMrData().getRaceTable().getRaces();

		for (Race objRace : race) {
			
			MongoCollection<Document> coll = utilBanco.conectarBanco(tabelaCorrida);
			Document doc = new Document();

			doc.put("serie", corrida_.getMrData().getSeries().toString());
			doc.put("temporada", corrida_.getMrData().getRaceTable().getSeason().toString());
			doc.put("round", corrida_.getMrData().getRaceTable().getRound().toString());
			doc.put("resultado", corrida_.getMrData().getTotal().toString());
			doc.put("nomeCorrida", objRace.getRaceName().toString());

			try {
				System.out.println("==> insert na tabela= " + tabelaCorrida + " registro= " + doc);
				 coll.insertOne(doc);
			} catch (Exception e) {
				return respostasUtil.getRequisicaoInvalida(MENSAGEM_INCLUSAO_NAO_REALIZADA);
			}

			BasicDBObject andQuery = new BasicDBObject();
			List<BasicDBObject> obj = new ArrayList<BasicDBObject>();
			
			obj.add(new BasicDBObject("round", corrida_.getMrData().getRaceTable().getRound().toString()));
			obj.add(new BasicDBObject("temporada", corrida_.getMrData().getRaceTable().getSeason().toString()));
			andQuery.put("$and", obj);

			MongoCollection<Document> collPesquisa = utilBanco.conectarBanco(tabelaCorrida);						
			MongoCursor<Document> cursor = collPesquisa.find(andQuery).iterator();

			while (cursor.hasNext()) {
				Document result = (Document) cursor.next();
				idCorrida =  result.get("_id").toString();	
			}

			/// após incluir a corrida, será incluído os resultados



			List<Result> resultado = new ArrayList<Result>();
			resultado = objRace.getResults();
			for (Result objResult : resultado) {
				
				MongoCollection<Document> collResult = utilBanco.conectarBanco(tabelaResultado);
				Document docResult = new Document();
				
				docResult.put("idCorrida", idCorrida);

				if ((objResult.getStatus().toString().equalsIgnoreCase("finished"))
						|| (objResult.getStatus().toString().contains("+"))) {
					docResult.put("posicao", objResult.getPosition().toString());
				} else {
					docResult.put("posicao", "R");
				}

				docResult.put("numero", objResult.getNumber().toString());
				docResult.put("nomePiloto", objResult.getDriver().getGivenName().toString());
				docResult.put("sobrenomePiloto", objResult.getDriver().getFamilyName().toString());
				docResult.put("equipe", objResult.getConstructor().getName().toString());
				docResult.put("voltas", objResult.getLaps().toString());
				docResult.put("grid", objResult.getGrid().toString());
				docResult.put("tempo",
						((objResult.getTime() != null) ? objResult.getTime().getTime().toString() : " "));
				docResult.put("status", objResult.getStatus().toString());
				docResult.put("pontos", objResult.getPoints().toString());

				try {
					System.out.println("==> insert na tabela= " + tabelaResultado + " registro= " + docResult);
					collResult.insertOne(docResult);
				} catch (Exception e) {
					return respostasUtil.getRequisicaoInvalida(MENSAGEM_INCLUSAO_NAO_REALIZADA);
				}
			}
		}
		return new ResponseEntity<Corrida>(corrida_, HttpStatus.OK);
	}

}
