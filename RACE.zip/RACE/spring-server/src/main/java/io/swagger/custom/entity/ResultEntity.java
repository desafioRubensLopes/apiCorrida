package io.swagger.custom.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.custom.repository.*;

@Entity
public class ResultEntity implements Serializable {

	private static final long serialVersionUID = -5554866530519083481L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long number;
	private Integer position;
	private String positionText;
	private Integer points;
	private DriverEntity Driver;
	private ConstructorEntity Constructor;
	private Integer grid;
	private Integer laps;
	private String status;
	private TimeEntity Time;
	private FastestLapEntity FastestLap;
	public Long getNumber() {
		return number;
	}
	public void setNumber(Long number) {
		this.number = number;
	}
	public Integer getPosition() {
		return position;
	}
	public void setPosition(Integer position) {
		this.position = position;
	}
	public String getPositionText() {
		return positionText;
	}
	public void setPositionText(String positionText) {
		this.positionText = positionText;
	}
	public Integer getPoints() {
		return points;
	}
	public void setPoints(Integer points) {
		this.points = points;
	}
	public DriverEntity getDriver() {
		return Driver;
	}
	public void setDriver(DriverEntity driver) {
		Driver = driver;
	}
	public ConstructorEntity getConstructor() {
		return Constructor;
	}
	public void setConstructor(ConstructorEntity constructor) {
		Constructor = constructor;
	}
	public Integer getGrid() {
		return grid;
	}
	public void setGrid(Integer grid) {
		this.grid = grid;
	}
	public Integer getLaps() {
		return laps;
	}
	public void setLaps(Integer laps) {
		this.laps = laps;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public TimeEntity getTime() {
		return Time;
	}
	public void setTime(TimeEntity time) {
		Time = time;
	}
	public FastestLapEntity getFastestLap() {
		return FastestLap;
	}
	public void setFastestLap(FastestLapEntity fastestLap) {
		FastestLap = fastestLap;
	}
	
	

}
