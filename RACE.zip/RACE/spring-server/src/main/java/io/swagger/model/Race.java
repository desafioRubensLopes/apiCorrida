package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Circuit;
import io.swagger.model.Result;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.LocalDate;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Race
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-09T19:08:55.979Z")

public class Race   {
  @JsonProperty("season")
  private Integer season = null;

  @JsonProperty("round")
  private Integer round = null;

  @JsonProperty("url")
  private String url = null;

  @JsonProperty("raceName")
  private String raceName = null;

  @JsonProperty("Circuit")
  private Circuit circuit = null;

  @JsonProperty("date")
  private LocalDate date = null;

  @JsonProperty("time")
  private String time = null;

  @JsonProperty("Results")
  @Valid
  private List<Result> results = null;

  public Race season(Integer season) {
    this.season = season;
    return this;
  }

  /**
   * Get season
   * @return season
  **/
  @ApiModelProperty(example = "2017", value = "")


  public Integer getSeason() {
    return season;
  }

  public void setSeason(Integer season) {
    this.season = season;
  }

  public Race round(Integer round) {
    this.round = round;
    return this;
  }

  /**
   * Get round
   * @return round
  **/
  @ApiModelProperty(example = "20", value = "")


  public Integer getRound() {
    return round;
  }

  public void setRound(Integer round) {
    this.round = round;
  }

  public Race url(String url) {
    this.url = url;
    return this;
  }

  /**
   * Get url
   * @return url
  **/
  @ApiModelProperty(example = "https://en.wikipedia.org/wiki/2017_Abu_Dhabi_Grand_Prix", value = "")


  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public Race raceName(String raceName) {
    this.raceName = raceName;
    return this;
  }

  /**
   * Get raceName
   * @return raceName
  **/
  @ApiModelProperty(example = "Abu Dhabi Grand Prix", value = "")


  public String getRaceName() {
    return raceName;
  }

  public void setRaceName(String raceName) {
    this.raceName = raceName;
  }

  public Race circuit(Circuit circuit) {
    this.circuit = circuit;
    return this;
  }

  /**
   * Get circuit
   * @return circuit
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Circuit getCircuit() {
    return circuit;
  }

  public void setCircuit(Circuit circuit) {
    this.circuit = circuit;
  }

  public Race date(LocalDate date) {
    this.date = date;
    return this;
  }

  /**
   * Get date
   * @return date
  **/
  @ApiModelProperty(example = "", value = "")

  @Valid

  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }

  public Race time(String time) {
    this.time = time;
    return this;
  }

  /**
   * Get time
   * @return time
  **/
  @ApiModelProperty(example = "13:00:00Z", value = "")


  public String getTime() {
    return time;
  }

  public void setTime(String time) {
    this.time = time;
  }

  public Race results(List<Result> results) {
    this.results = results;
    return this;
  }

  public Race addResultsItem(Result resultsItem) {
    if (this.results == null) {
      this.results = new ArrayList<Result>();
    }
    this.results.add(resultsItem);
    return this;
  }

  /**
   * Get results
   * @return results
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<Result> getResults() {
    return results;
  }

  public void setResults(List<Result> results) {
    this.results = results;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Race race = (Race) o;
    return Objects.equals(this.season, race.season) &&
        Objects.equals(this.round, race.round) &&
        Objects.equals(this.url, race.url) &&
        Objects.equals(this.raceName, race.raceName) &&
        Objects.equals(this.circuit, race.circuit) &&
        Objects.equals(this.date, race.date) &&
        Objects.equals(this.time, race.time) &&
        Objects.equals(this.results, race.results);
  }

  @Override
  public int hashCode() {
    return Objects.hash(season, round, url, raceName, circuit, date, time, results);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Race {\n");
    
    sb.append("    season: ").append(toIndentedString(season)).append("\n");
    sb.append("    round: ").append(toIndentedString(round)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    raceName: ").append(toIndentedString(raceName)).append("\n");
    sb.append("    circuit: ").append(toIndentedString(circuit)).append("\n");
    sb.append("    date: ").append(toIndentedString(date)).append("\n");
    sb.append("    time: ").append(toIndentedString(time)).append("\n");
    sb.append("    results: ").append(toIndentedString(results)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

