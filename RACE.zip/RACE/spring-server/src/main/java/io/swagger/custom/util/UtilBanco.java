package io.swagger.custom.util;

import org.springframework.beans.factory.annotation.Autowired;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.DeleteResult;

import io.swagger.custom.repository.Corridas;
import io.swagger.custom.util.RespostasUtil;

@Component
public class UtilBanco {
	
	public static final String MENSAGEM_ERRO_CONECTAXAO = "não foi possivel conectado ao banco de dados";

	@Autowired
	private static RespostasUtil respostasUtil;
	
	public static MongoCollection<Document> conectarBanco(String table) {
	 
		try {	
			
			MongoClient mongoClient = MongoClients.create("mongodb://127.0.0.1:27017");
			MongoDatabase db = mongoClient.getDatabase("db");
			MongoCollection<Document> collection = db.getCollection(table);
			
			return collection;
			
		} catch (Exception e) {
			throw new RuntimeException("Falha ao conectar no banco de dados");
		}

	}
	


}
