package io.swagger.custom.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.custom.repository.*;

@Entity
public class ConstructorEntity implements Serializable {
	private static final long serialVersionUID = -5554866530519083481L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String driverId;
	private String constructorId;
	private String url;
	private String name;
	private String nationality;
	public String getDriverId() {
		return driverId;
	}
	public void setDriverId(String driverId) {
		this.driverId = driverId;
	}
	public String getConstructorId() {
		return constructorId;
	}
	public void setConstructorId(String constructorId) {
		this.constructorId = constructorId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	
	

}
