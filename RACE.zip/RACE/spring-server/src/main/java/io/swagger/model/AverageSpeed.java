package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * AverageSpeed
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-09T19:08:55.979Z")

public class AverageSpeed   {
  @JsonProperty("units")
  private String units = null;

  @JsonProperty("speed")
  private Double speed = null;

  public AverageSpeed units(String units) {
    this.units = units;
    return this;
  }

  /**
   * Get units
   * @return units
  **/
  @ApiModelProperty(example = "kph", value = "")


  public String getUnits() {
    return units;
  }

  public void setUnits(String units) {
    this.units = units;
  }

  public AverageSpeed speed(Double speed) {
    this.speed = speed;
    return this;
  }

  /**
   * Get speed
   * @return speed
  **/
  @ApiModelProperty(example = "198.652", value = "")


  public Double getSpeed() {
    return speed;
  }

  public void setSpeed(Double speed) {
    this.speed = speed;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AverageSpeed AverageSpeed = (AverageSpeed) o;
    return Objects.equals(this.units, AverageSpeed.units) &&
        Objects.equals(this.speed, AverageSpeed.speed);
  }

  @Override
  public int hashCode() {
    return Objects.hash(units, speed);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AverageSpeed {\n");
    
    sb.append("    units: ").append(toIndentedString(units)).append("\n");
    sb.append("    speed: ").append(toIndentedString(speed)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

