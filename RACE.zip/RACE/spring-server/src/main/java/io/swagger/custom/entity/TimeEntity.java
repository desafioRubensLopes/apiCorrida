package io.swagger.custom.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.custom.repository.*;

@Entity
public class TimeEntity implements Serializable {

	private static final long serialVersionUID = -5554866530519083481L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long millis;
	private String time;
	public Long getMillis() {
		return millis;
	}
	public void setMillis(Long millis) {
		this.millis = millis;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
	
}
