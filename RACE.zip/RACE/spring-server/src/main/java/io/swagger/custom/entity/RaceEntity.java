package io.swagger.custom.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.custom.repository.*;

@Entity
public class RaceEntity implements Serializable {

	private static final long serialVersionUID = -5554866530519083481L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer season;
	private Integer round;
	private String url;
	private String raceName;
	private CircuitEntity circuit;
	private LocalDate date;
	private String time;
	//private List<ResultEntity> results;
	private ResultEntity results;
	public Integer getSeason() {
		
		return season;
	}
	public void setSeason(Integer season) {
		this.season = season;
	}
	public Integer getRound() {
		return round;
	}
	public void setRound(Integer round) {
		this.round = round;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getRaceName() {
		return raceName;
	}
	public void setRaceName(String raceName) {
		this.raceName = raceName;
	}
	public CircuitEntity getCircuit() {
		return circuit;
	}
	public void setCircuit(CircuitEntity circuit) {
		this.circuit = circuit;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public ResultEntity getResults() {
		return results;
	}
	public void setResults(ResultEntity results) {
		this.results = results;
	}

	
	
}
