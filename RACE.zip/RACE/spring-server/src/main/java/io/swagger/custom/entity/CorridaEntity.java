package io.swagger.custom.entity;

import java.io.Serializable;
import org.threeten.bp.LocalDate;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.threeten.bp.OffsetDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;


@Entity
public class CorridaEntity implements Serializable{

	private static final long serialVersionUID = -1744498845582568202L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private MRDataEntity MRData;

	public MRDataEntity getMRData() {
		return MRData;
	}

	public void setMRData(MRDataEntity mRData) {
		MRData = mRData;
	}
	
	

}
