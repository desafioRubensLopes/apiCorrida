package io.swagger.custom.util;

import java.util.List;

import org.bson.Document;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.mongodb.client.MongoCollection;


import io.swagger.model.Corrida;

@Component
public class RespostasUtil {
	
	public static final String HEADER_MENSAGEM = "Mensagem: ";
	
	public static final String HEADER_ERRO = "Erro: ";
	
	private MultiValueMap<String, String> getNovoHeaderComMensagem(String mensagem) {
		MultiValueMap<String, String> header = new LinkedMultiValueMap<String, String>();
		header.add(HEADER_MENSAGEM, mensagem);
		return header;
	}
	
	public ResponseEntity<Void> getErroInterno(String mensagem) {
		return new ResponseEntity<Void>(getNovoHeaderComMensagem(mensagem), HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public ResponseEntity<Void> getSucessoSemConteudo(String mensagem) {
		return new ResponseEntity<Void>(getNovoHeaderComMensagem(mensagem), HttpStatus.NO_CONTENT);
	}

	public ResponseEntity<Corrida> getRequisicaoInvalida(String mensagem) {
		return new ResponseEntity<Corrida>(getNovoHeaderComMensagem(mensagem), HttpStatus.BAD_REQUEST);
	}
	
	public ResponseEntity<Void> getNaoAutorizado(String mensagem) {
		return new ResponseEntity<Void>(getNovoHeaderComMensagem(mensagem), HttpStatus.UNAUTHORIZED);
	}	

	public ResponseEntity<Double> getErroInternoDouble(String mensagem) {

		return new ResponseEntity<Double>(getNovoHeaderComMensagem(mensagem),HttpStatus.INTERNAL_SERVER_ERROR);
	}

	public ResponseEntity<Double> getRequisicaoInvalidaDouble(String mensagem) {
		return new ResponseEntity<Double>(getNovoHeaderComMensagem(mensagem), HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<Double> getNaoAutorizadoDouble(String mensagem) {
		return new ResponseEntity<Double>(getNovoHeaderComMensagem(mensagem), HttpStatus.UNAUTHORIZED);
	}

	public ResponseEntity<List<Corrida>> getNaoAutorizadoListCorrida(String mensagem) {
		return new ResponseEntity<List<Corrida>>(getNovoHeaderComMensagem(mensagem), HttpStatus.UNAUTHORIZED);
	}

	public ResponseEntity<Corrida> getNaoAutorizadoCorrida(String mensagem) {
		return new ResponseEntity<Corrida>(getNovoHeaderComMensagem(mensagem), HttpStatus.UNAUTHORIZED);
	}

	public ResponseEntity<Corrida> getRequisicaoInvalidaCorrida(String mensagem) {
		return new ResponseEntity<Corrida>(getNovoHeaderComMensagem(mensagem), HttpStatus.BAD_REQUEST);
	}

	public ResponseEntity<List<Corrida>> getRegistroNaoEncontradoListCorrida(String mensagem) {
		return new ResponseEntity<List<Corrida>>(getNovoHeaderComMensagem(mensagem), HttpStatus.BAD_REQUEST);
	}

}
