package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.RaceTable;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * MRData
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-09T19:08:55.979Z")


@JsonPropertyOrder({"xmlns", "series", "url", "limit", "offset", "total", "RaceTable"}) 
public class MRData   {
  @JsonProperty("xmlns")
  private String xmlns = null;

  @JsonProperty("series")
  private String series = null;

  @JsonProperty("url")
  private String url = null;

  @JsonProperty("limit")
  private Integer limit = null;

  @JsonProperty("offset")
  private Integer offset = null;

  @JsonProperty("total")
  private Integer total = null;

  @JsonProperty("RaceTable")
  private RaceTable RaceTable = null;
  
  @JsonCreator
	public MRData(@JsonProperty("xmlns") String xmlns, @JsonProperty("series") String series,
			@JsonProperty("url") String url, @JsonProperty("limit") Integer limit,
			@JsonProperty("offset") Integer offset, @JsonProperty("total") Integer total,
			@JsonProperty("RaceTable") RaceTable RaceTable) {
	  this.xmlns = xmlns;
	  this.series= series;
	  this.url = url;
	  this.limit = limit;
	  this.offset = offset;
	  this.total = total;
	  this.RaceTable = RaceTable;
	  }

  public MRData xmlns(String xmlns) {
    this.xmlns = xmlns;
    return this;
  }

  /**
   * Get xmlns
   * @return xmlns
  **/
  @ApiModelProperty(example = "http://ergast.com/mr/1.4", value = "")


  public String getXmlns() {
    return xmlns;
  }

  public void setXmlns(String xmlns) {
    this.xmlns = xmlns;
  }

  public MRData series(String series) {
    this.series = series;
    return this;
  }

  /**
   * Get series
   * @return series
  **/
  @ApiModelProperty(example = "f1", value = "")


  public String getSeries() {
    return series;
  }

  public void setSeries(String series) {
    this.series = series;
  }

  public MRData url(String url) {
    this.url = url;
    return this;
  }

  /**
   * Get url
   * @return url
  **/
  @ApiModelProperty(example = "http://ergast.com/api/f1/2017/last/results.json", value = "")


  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public MRData limit(Integer limit) {
    this.limit = limit;
    return this;
  }

  /**
   * Get limit
   * @return limit
  **/
  @ApiModelProperty(example = "30", value = "")


  public Integer getLimit() {
    return limit;
  }

  public void setLimit(Integer limit) {
    this.limit = limit;
  }

  public MRData offset(Integer offset) {
    this.offset = offset;
    return this;
  }

  /**
   * Get offset
   * @return offset
  **/
  @ApiModelProperty(example = "0", value = "")


  public Integer getOffset() {
    return offset;
  }

  public void setOffset(Integer offset) {
    this.offset = offset;
  }

  public MRData total(Integer total) {
    this.total = total;
    return this;
  }

  /**
   * Get total
   * @return total
  **/
  @ApiModelProperty(example = "20", value = "")


  public Integer getTotal() {
    return total;
  }

  public void setTotal(Integer total) {
    this.total = total;
  }

  public MRData RaceTable(RaceTable RaceTable) {
    this.RaceTable = RaceTable;
    return this;
  }

  /**
   * Get RaceTable
   * @return RaceTable
  **/
  @ApiModelProperty(value = "")

  @Valid

  public RaceTable getRaceTable() {
    return RaceTable;
  }

  public void setRaceTable(RaceTable RaceTable) {
    this.RaceTable = RaceTable;
  }


  @Override
  @JsonPropertyOrder({"xmlns", "series", "url", "limit", "offset", "total", "RaceTable"}) 
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MRData MRData= (MRData) o;
    return Objects.equals(this.xmlns, MRData.xmlns) &&
        Objects.equals(this.series, MRData.series) &&
        Objects.equals(this.url, MRData.url) &&
        Objects.equals(this.limit, MRData.limit) &&
        Objects.equals(this.offset, MRData.offset) &&
        Objects.equals(this.total, MRData.total) &&
        Objects.equals(this.RaceTable, MRData.RaceTable);
  }

  @Override
  public int hashCode() {
    return Objects.hash(xmlns, series, url, limit, offset, total, RaceTable);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MRData {\n");
    
    sb.append("    xmlns: ").append(toIndentedString(xmlns)).append("\n");
    sb.append("    series: ").append(toIndentedString(series)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    limit: ").append(toIndentedString(limit)).append("\n");
    sb.append("    offset: ").append(toIndentedString(offset)).append("\n");
    sb.append("    total: ").append(toIndentedString(total)).append("\n");
    sb.append("    RaceTable: ").append(toIndentedString(RaceTable)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

