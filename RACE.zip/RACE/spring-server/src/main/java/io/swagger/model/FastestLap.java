package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * FastestLap
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-09T19:08:55.979Z")

public class FastestLap   {
  @JsonProperty("rank")
  private Integer rank = null;

  @JsonProperty("lap")
  private Integer lap = null;
  
  @JsonProperty("Time")
  private Time Time = null;

  @JsonProperty("AverageSpeed")
  private AverageSpeed AverageSpeed = null;

  public FastestLap rank(Integer rank) {
    this.rank = rank;
    return this;
  }

  /**
   * Get rank
   * @return rank
  **/
  @ApiModelProperty(example = "1", value = "")


  public Integer getRank() {
    return rank;
  }

  public void setRank(Integer rank) {
    this.rank = rank;
  }

  public FastestLap lap(Integer lap) {
    this.lap = lap;
    return this;
  }

  /**
   * Get lap
   * @return lap
  **/
  @ApiModelProperty(example = "52", value = "")


  public Integer getLap() {
    return lap;
  }

  public void setLap(Integer lap) {
    this.lap = lap;
  }

  public FastestLap Time(Time Time) {
	    this.Time = Time;
	    return this;
	  }

	  /**
	   * Get Time
	   * @return Time
	  **/
	  @ApiModelProperty(value = "")

	  @Valid

	  public Time getTime() {
	    return Time;
	  }

	  public void setTime(Time Time) {
	    this.Time = Time;
	  }

	  public FastestLap AverageSpeed(AverageSpeed AverageSpeed) {
	    this.AverageSpeed = AverageSpeed;
	    return this;
	  }

	  /**
	   * Get AverageSpeed
	   * @return AverageSpeed
	  **/
	  @ApiModelProperty(value = "")

	  @Valid

	  public AverageSpeed getAverageSpeed() {
	    return AverageSpeed;
	  }

	  public void setAverageSpeed(AverageSpeed AverageSpeed) {
	    this.AverageSpeed = AverageSpeed;
	  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FastestLap FastestLap = (FastestLap) o;
    return Objects.equals(this.rank, FastestLap.rank) &&
        Objects.equals(this.lap, FastestLap.lap) &&
    Objects.equals(this.Time, FastestLap.Time) &&
    Objects.equals(this.AverageSpeed, FastestLap.AverageSpeed);
  }

  @Override
  public int hashCode() {
    return Objects.hash(rank, lap, Time, AverageSpeed);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FastestLap {\n");
    
    sb.append("    rank: ").append(toIndentedString(rank)).append("\n");
    sb.append("    lap: ").append(toIndentedString(lap)).append("\n");
    sb.append("    Time: ").append(toIndentedString(Time)).append("\n");
    sb.append("    AverageSpeed: ").append(toIndentedString(AverageSpeed)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

