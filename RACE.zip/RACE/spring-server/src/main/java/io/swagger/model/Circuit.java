package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Location;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Circuit
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-09T19:08:55.979Z")

public class Circuit   {
  @JsonProperty("circuitId")
  private String circuitId = null;

  @JsonProperty("url")
  private String url = null;

  @JsonProperty("circuitName")
  private String circuitName = null;

  @JsonProperty("Location")
  private Location Location = null;

  public Circuit circuitId(String circuitId) {
    this.circuitId = circuitId;
    return this;
  }

  /**
   * Get circuitId
   * @return circuitId
  **/
  @ApiModelProperty(example = "yas_marina", value = "")


  public String getCircuitId() {
    return circuitId;
  }

  public void setCircuitId(String circuitId) {
    this.circuitId = circuitId;
  }

  public Circuit url(String url) {
    this.url = url;
    return this;
  }

  /**
   * Get url
   * @return url
  **/
  @ApiModelProperty(example = "http://en.wikipedia.org/wiki/Yas_Marina_Circuit", value = "")


  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  public Circuit circuitName(String circuitName) {
    this.circuitName = circuitName;
    return this;
  }

  /**
   * Get circuitName
   * @return circuitName
  **/
  @ApiModelProperty(example = "Yas Marina Circuit", value = "")


  public String getCircuitName() {
    return circuitName;
  }

  public void setCircuitName(String circuitName) {
    this.circuitName = circuitName;
  }

  public Circuit Location(Location Location) {
    this.Location = Location;
    return this;
  }

  /**
   * Get Location
   * @return Location
  **/
  @ApiModelProperty(value = "")

  @Valid

  public Location getLocation() {
    return Location;
  }

  public void setLocation(Location Location) {
    this.Location = Location;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Circuit circuit = (Circuit) o;
    return Objects.equals(this.circuitId, circuit.circuitId) &&
        Objects.equals(this.url, circuit.url) &&
        Objects.equals(this.circuitName, circuit.circuitName) &&
        Objects.equals(this.Location, circuit.Location);
  }

  @Override
  public int hashCode() {
    return Objects.hash(circuitId, url, circuitName, Location);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Circuit {\n");
    
    sb.append("    circuitId: ").append(toIndentedString(circuitId)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    circuitName: ").append(toIndentedString(circuitName)).append("\n");
    sb.append("    Location: ").append(toIndentedString(Location)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

