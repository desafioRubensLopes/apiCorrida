package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Race;
import java.util.ArrayList;
import java.util.List;
import org.threeten.bp.LocalDate;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * RaceTable
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2019-06-09T19:08:55.979Z")

public class RaceTable   {
  @JsonProperty("season")
  private Integer season = null;

  @JsonProperty("round")
  private String round = null;

  @JsonProperty("Races")
  @Valid
  private List<Race> Races = null;
  
  @JsonCreator
	public RaceTable(@JsonProperty("season") Integer season, @JsonProperty("round") String round,
			@JsonProperty("Races") List<Race> Races) {
	  this.season = season;
	  this.round = round;
	  this.Races = Races;
	  }

  public RaceTable season(Integer season) {
    this.season = season;
    return this;
  }

  /**
   * Get season
   * @return season
  **/
  @ApiModelProperty(example = "", value = "")

  @Valid

  public Integer getSeason() {
    return season;
  }

  public void setSeason(Integer season) {
    this.season = season;
  }

  public RaceTable round(String round) {
    this.round = round;
    return this;
  }

  /**
   * Get round
   * @return round
  **/
  @ApiModelProperty(example = "13:00:00Z", value = "")


  public String getRound() {
    return round;
  }

  public void setRound(String round) {
    this.round = round;
  }

  public RaceTable Races(List<Race> Races) {
    this.Races = Races;
    return this;
  }

  public RaceTable addRacesItem(Race RacesItem) {
    if (this.Races == null) {
      this.Races = new ArrayList<Race>();
    }
    this.Races.add(RacesItem);
    return this;
  }

  /**
   * Get Races
   * @return Races
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<Race> getRaces() {
    return Races;
  }

  public void setRaces(List<Race> Races) {
    this.Races = Races;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RaceTable RaceTable = (RaceTable) o;
    return Objects.equals(this.season, RaceTable.season) &&
        Objects.equals(this.round, RaceTable.round) &&
        Objects.equals(this.Races, RaceTable.Races);
  }

  @Override
  public int hashCode() {
    return Objects.hash(season, round, Races);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RaceTable {\n");
    
    sb.append("    season: ").append(toIndentedString(season)).append("\n");
    sb.append("    round: ").append(toIndentedString(round)).append("\n");
    sb.append("    Races: ").append(toIndentedString(Races)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

